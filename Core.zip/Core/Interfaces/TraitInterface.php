<?php
namespace Interfaces;

/**
 * Trait Interface
 * ============================================
 * ================= CodeHart(Bruiz) ==========
 * ============================================
 */

interface TraitInterface {
    
}