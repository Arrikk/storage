<?php

$GLOBALS['user'] = $__user ?? [];


__links([
    '__title' => $__title ?? '',
    '__class' => $__class ?? ''
]);
__nav();
require_once dirname(__FILE__) . $__page . '.html';
__alert();
__modal();
__script();
